﻿# wyagd001.github.io
个人主页, [Autohotkey v1 中文帮助](https://wyagd001.github.io/zh-cn/index.html),   [Autohotkey v2 中文帮助](https://wyagd001.github.io/v2/index.html),   [自用脚本 运行-Ahk 简介](https://wyagd001.github.io/Run-Ahk/),   [如意-Ahk 简介](https://wyagd001.github.io/RuYi-Ahk/)  

编译好的 chm 帮助文件在 [github](https://raw.githubusercontent.com/wyagd001/RuYi-Ahk/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm) 或 [gitee](https://gitee.com/wyagd001/RuYi-Ahk/raw/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm) 下载
感谢您的支持

<img src="https://wyagd001.github.io/img/coffee.png" alt="Image text" width="256px" />

![Image text](https://autohotkey.com/assets/images/ahk-logo-no-text241x78-180.png)