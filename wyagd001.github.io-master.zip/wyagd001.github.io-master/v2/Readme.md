﻿ 编译 chm 文件说明   
1. 安装 HTML Help Workshop(hhc.exe)   
2. 下载库, 解压进入 v2 文件夹   
3. 修改 compile_chm.ahk 文件中变量 hhc 的值为 hhc.exe 程序的实际路径   
4. 运行 compile_chm.ahk 自动编译生成 chm 文件   
5. 如果需要更新搜索列表, 需在编译前运行 build_search.ahk 一次   

PS:  
编译好的 chm 文件下载地址:  
https://github.com/wyagd001/RuYi-Ahk/blob/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm   

https://github.com/wyagd001/RuYi-Ahk/raw/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm   
下载链接: [github](https://raw.githubusercontent.com/wyagd001/RuYi-Ahk/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm) 或 [gitee](https://gitee.com/wyagd001/RuYi-Ahk/raw/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm)   