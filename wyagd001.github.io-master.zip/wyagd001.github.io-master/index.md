﻿---
layout: default
---

AutoHotkey 中文帮助&emsp; [[v1]](zh-cn/docs/index.htm) &emsp; [[v2]](v2/docs/index.htm)  
自用脚本介绍&emsp; &emsp; &emsp;    [运行-Ahk](Run-Ahk/index.md)  &emsp; [如意-Ahk](RuYi-Ahk/index.md)  

如果您觉得有用, 可以请作者喝杯咖啡. 感谢您的支持!  
编译好的 chm 帮助文件在 [github](https://raw.githubusercontent.com/wyagd001/RuYi-Ahk/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm) 或 [gitee](https://gitee.com/wyagd001/RuYi-Ahk/raw/main/%E5%BC%95%E7%94%A8%E7%A8%8B%E5%BA%8F/2.0/AutoHotkey2.0.chm) 下载

<!-- ![Image text](https://raw.githubusercontent.com/wyagd001/wyagd001.github.io/master/img/coffee.png) -->
<!-- ![Image text](https://wyagd001.github.io/img/coffee.png){:height="256px" width="256px"}-->
<img src="https://wyagd001.github.io/img/coffee.png" alt="Image text" width="256px" />

![AutoHotkey](https://wyagd001.github.io/img/ahk-logo-no-text241x78-180.png)